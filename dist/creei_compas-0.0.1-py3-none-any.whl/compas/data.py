import pandas as pd 
import numpy as np 
from multiprocessing import Pool as pool 
from multiprocessing import cpu_count
from functools import partial 
from os import path
import pickle 
params_dir = path.join(path.dirname(__file__), 'params/')

def bdsps(file,year=2017,iprint=False):
    df = pd.read_stata(file,convert_categoricals=False)
    df = df[df.hdprov==4]
    df = df[['hdseqhh','hdwgthh','hdwgthhs','idefseq','idefrh','hhnef','idage','idspoflg',
         'idimmi','idedlev','idestat','idmarst','efnkids','imqndc','hdnkids','idsex']]
    keep = []
    keys = df.groupby(['hdseqhh','idefseq']).count()['hdwgthh'].to_frame()
    keys.columns = ['ncount']
    keys['hhid'] = np.arange(len(keys))
    keys = keys.reset_index()
    df = df.merge(keys,left_on=['hdseqhh','idefseq'],right_on=['hdseqhh','idefseq'],how='left')
    keep.append('hhid')
    df['age'] = df.loc[:,'idage']
    df['age'] = np.where(df['age']==0,0,df['age'])
    keep.append('age')
    df['byr'] = year - df['age']
    df['byr'] = np.where(df['byr']>year,year,df['byr'])
    df['byr'].describe()
    keep.append('byr')
    df['male'] = df.idsex.replace({1:True,0:False})
    keep.append('male')
    df['immig'] = df.idimmi!=99
    df['newimm'] = df.idimmi<10
    df['yrsimm'] = df.idimmi.replace(99,np.nan)
    keep.append('immig')
    keep.append('newimm')
    keep.append('yrsimm')
    educ = {0:'none',1:'none',2:'none',3:'none',4:'none',5:'none',6:'des',
            7:'des',8:'des',9:'dec',10:'dec',11:'uni',12:'uni'}
    df['educ4'] = df.idedlev.replace(educ)
    keep.append('educ4')
    df['inschool'] = df.idestat.replace({0:False,1:True,2:True,3:True})
    keep.append('inschool')
    df['married'] = df['idmarst'].replace({0:True,1:True,2:False,3:False,4:False,5:False})
    keep.append('married')
    df['spflag'] = df.loc[:,'idspoflg']
    keep.append('spflag')
    df['wgt'] = df.loc[:,'hdwgthh']
    totpop = df['wgt'].sum()
    keep.append('wgt')
    df['pn'] = df.loc[:,'idefrh'].astype('Int64')
    keep.append('pn')
    df['nas'] = np.arange(len(df))
    df['nas'] = df['nas'].astype('Int64')
    keep.append('nas')
    # for each nas in df (dominant), drop adults in households, including chidlren
    # older than 18. 
    pop = df.loc[df['pn']!=3,keep]
    kids18p = (pop.age>=18) & (pop.pn==2)
    #pop = pop[kids18p!=True]
    # calibrate weights by age and sex
    samp = pop.groupby(['age','male']).sum()['wgt'].unstack()
    samp.columns = ['female','male']
    samp = samp[['male','female']]
    cens = isq(year)
    totpop = cens.sum().sum()
    cens = cens[cens.index!=100]
    wgt = cens/samp
    wgt.columns = [True,False]
    wgt = wgt.stack()      
    wgt.index.names = ['age','male']
    wgt = wgt.reset_index()
    wgt.columns = ['age','male','adj']
    pop = pop.merge(wgt,on=['age','male'])
    pop['wgt'] = pop['wgt'] * pop['adj']
    pop['wgt'] *= totpop/pop['wgt'].sum()
    pop = pop.drop(columns=['adj'])
    
    # dominants
    hh = pop.copy()
    
    # spouses
    sps = hh.loc[hh.pn!=2,:]
    keys = sps[['hhid','pn','nas']]
    keys.columns = ['hhid','pn_dom','nas_dom']
    sps.loc[:,'pn_dom'] = 1-sps.loc[:,'pn'].values
    sp = sps.merge(keys,left_on=['hhid','pn_dom'],right_on=['hhid','pn_dom'],how='left')
    sp = sp[sp.nas_dom.isna()==False]
    sp['nas'] = sp['nas_dom']
    sp = sp.drop(labels=['nas_dom','pn_dom'],axis=1)
    
    # kids
    kds = hh.loc[hh.pn==2,:]
    kds = kds[kds.age<18]
    keys = hh.loc[hh.pn!=2,['hhid','nas']]
    keys.columns = ['hhid','nas_dom']
    fams = keys.groupby(keys['hhid']).count()
    fams.columns = ['nparents']
    kds = kds.merge(fams['nparents'],left_on=['hhid'],right_index=True,how='left')
    
    # kids with one parent
    kds_1p = kds.loc[kds['nparents']==1,:]
    kids_1p = kds_1p.merge(keys,left_on=['hhid'],right_on=['hhid'],how='left')
    kids_1p['nas'] = kids_1p['nas_dom'] 
    kids_1p = kids_1p.drop(labels=['nas_dom'],axis=1)
    
    # kids with two parents
    kds_2p = kds.loc[kds['nparents']==2,:]
    sps = hh.loc[hh.pn!=2,:]
    keys = sps[['hhid','pn','nas']]   
    keys.columns = ['hhid','pn_dom','nas_dom']
    keys_0 = keys.loc[keys.pn_dom==0,:] 
    keys_1 = keys.loc[keys.pn_dom==1,:] 
    kds_2p_0 = kds_2p.merge(keys_0,left_on='hhid',right_on='hhid',how='inner')
    kds_2p_1 = kds_2p.merge(keys_1,left_on='hhid',right_on='hhid',how='inner')
    kids_2p = kds_2p_0.append(kds_2p_1)
    kids_2p['nas'] = kids_2p['nas_dom']
    kids_2p = kids_2p.drop(labels=['pn_dom','nas_dom'],axis=1)
    
    # join back datasets
    kd = kids_1p.append(kids_2p)
    
    # index
    hh = hh.set_index('nas').sort_index()
    sp = sp.set_index('nas').sort_index()
    kd = kd.set_index('nas').sort_index()
    
    # one case of an individual with spflag=1 but no spouse: drop flag
    check = hh.merge(sp['byr'],left_index=True,right_index=True,how='left',suffixes=('','_sp'))
    tocorrect = check.loc[(check.spflag==1) & (check.byr_sp.isna()==True)].index
    hh.loc[tocorrect,'spflag'] = 0
    
    # modify the married variable to match the spouse variable (some weird cases of separated but
    # living in same household)
    
    hh.married = hh.spflag==1
    
    # add variable number of kids to dominant dataset
    nkids = kd.groupby('nas').count()['age']
    nkids.name = 'nkids'
    hh = hh.merge(nkids,left_index=True,right_index=True,how='left') 
    hh.nkids = np.where(hh.nkids.isna(),0,hh.nkids)
    return hh,sp,kd

def isq(year):
    df = pd.read_excel(params_dir+'QC-age-sexe.xlsx',sheet_name='age',header=None,na_values='..')
    columns = ['year','niv','sex','total']
    for a in range(0,101):
        columns.append(a)
    columns.append('median')
    columns.append('mean')
    df.columns = columns
    df = df[(df['year']==year) & (df['sex']!=3)]
    df = df[[a for a in range(0,101)]].transpose()
    df.columns = ['male','female']
    df.index.name = 'age'
    return df
    

class parse:
    def __init__(self):
        self.vars_hh = ['wgt','byr','male','educ','insch','nkids','married']
        self.map_hh = dict(zip(self.vars_hh,self.vars_hh))
        self.vars_sp = ['byr','male','educ','insch']
        self.map_sp = dict(zip(self.vars_sp,self.vars_sp))
        self.vars_kd = ['byr','male','insch']
        self.map_kd = dict(zip(self.vars_kd,self.vars_kd))
        return
    def dominants(self,data):
        hh = pd.DataFrame(index=data.index,columns=self.vars_hh)
        for m in self.vars_hh:
            if self.map_hh[m] in data.columns:
                hh[m] = data[self.map_hh[m]]
        hh.index.name = 'nas'
        self.hh = hh
        hh.wgt = hh.wgt.astype('Float64')
        hh.nkids = hh.nkids.astype('Int64')
        return hh
    def spouses(self,data):
        n = len(data)
        if n==len(self.hh.index[self.hh.married]):
            sp = pd.DataFrame(index=data.index,columns=self.vars_sp)
            for m in self.vars_sp:
                if self.map_sp[m] in data.columns:
                    sp[m] = data[self.map_sp[m]]
            sp.index.name = 'nas'
            self.sp = sp
            return sp
        else :
            print('number of spouses in data not equal to number of dominants married')
            return None
    def kids(self,data):
        n = len(data)
        if n==self.hh['nkids'].sum():
            kd = pd.DataFrame(index=data.index,columns=self.vars_kd)
            for m in self.vars_kd:
                if self.map_kd[m] in data.columns:
                    kd[m] = data[self.map_kd[m]]
            kd.index.name = 'nas'
            self.kd = kd
            return kd
        else :
            print('number of kids in data not equal to total number of kids in dominant')
            return None


class population:
    def __init__(self):
        return
    def input(self,hh,sp,kd):
        self.hh = hh
        self.sp = sp
        self.kd = kd
        return 
    def load(self,file):
        handler = open(file+'.pkl', 'rb') 
        pop = pickle.load(handler)
        return pop
    def save(self,file):
        handler = open(file+'.pkl', 'wb') 
        pickle.dump(self,handler)
        return
    def size(self,w=True):
        if w:
            return self.hh['wgt'].sum()
        else:
            return len(self.hh)
    def gennas(self,n):
        maxnas = self.hh.index.max()
        return np.arange(maxnas+1,maxnas+1+n)
    def enter(self,imm,ntarget):
        nimm = len(imm.hh)
        nwgt = imm.hh.wgt.sum()
        imm.hh.wgt = imm.hh.wgt * ntarget/nwgt
        # generate new nas and assign
        new_nas = self.gennas(nimm)
        assign = dict(zip(imm.hh.index.values,new_nas))
        imm.hh.index = imm.hh.index.to_series().replace(assign)
        self.hh = self.hh.append(imm.hh)
        imm.sp.index = imm.sp.index.to_series().replace(assign)
        self.sp = self.sp.append(imm.sp)
        imm.kd.index = imm.kd.index.to_series().replace(assign)
        self.kd = self.kd.append(imm.kd)
        return 
    def exit(self,nastodrop):
        self.hh = self.hh.drop(nastodrop,errors='ignore')
        self.sp = self.sp.drop(nastodrop,errors='ignore')
        self.kd = self.kd.drop(nastodrop,errors='ignore')
        return
    def merge_spouses(self):
        return self.hh.merge(self.sp,left_index=True,right_index=True,
                             how='left',suffixes=('','_sp'))
    def nkids(self):
        nk = self.kd.groupby('nas').count()['byr']
        nk.name = 'nkids'
        self.hh.loc[nk.index,'nkids'] = nk
        self.hh.loc[~self.hh.index.isin(nk.index),'nkids'] = 0
        return 
    def ages(self,year):
        self.hh['age'] = year - self.hh['byr']
        self.sp['age'] = year - self.sp['byr']
        self.kd['age'] = year - self.kd['byr']
        return        
    def kagemin(self):
        am = self.kd.groupby('nas').min()['age']
        am.name = 'agemin'
        if 'agemin' in self.hh.columns:
            self.hh.loc[am.index,'agemin'] = am
            self.hh.loc[~self.hh.index.isin(am.index),'agemin'] = 0
        else :
            self.hh['agemin'] = 0
            self.hh.loc[am.index,'agemin'] = am
        return   

         